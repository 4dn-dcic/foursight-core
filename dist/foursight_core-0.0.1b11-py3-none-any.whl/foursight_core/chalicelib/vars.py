FOURSIGHT_PREFIX = 'foursight-core'
DEV_ENV = 'mastertest'
HOST = 'https://search-foursight-fourfront-ylxn33a5qytswm63z52uytgkm4.us-east-1.es.amazonaws.com'

