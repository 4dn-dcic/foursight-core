FOURSIGHT_PREFIX = 'foursight-cgap'
DEV_ENV = 'cgapdev'
