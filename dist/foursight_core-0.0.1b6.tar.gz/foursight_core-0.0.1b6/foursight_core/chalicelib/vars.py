FOURSIGHT_PREFIX = 'foursight'  # use 4dn as default so that testing on cgap would be useful
DEV_ENV = 'mastertest'  # use 4dn as default so that testing on cgap would be useful
